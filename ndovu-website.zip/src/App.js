import React from "react";

function App() {
  return (
    <div style={{ fontFamily: "Arial", padding: "2rem" }}>
      <h1>Welcome to Ndovu Building Company</h1>
      <p>Explore our house types, designs, plans, and pricing.</p>
    </div>
  );
}

export default App;
